# TechBlog - A blog for everyone
> This is an technical online blog

`Still under construction`

This is a generalized blog where people with different views and knowledge bases come together and create something remarkable.
We have created this blog specially to bring out people and to write about what they know. Most of the time people want to share their knowledge, their expertise but they don't have any platform to do so. And this is the platform what they are looking for. Every user who joins the system has a full access to the knowledge which is shared here. User can even search for any specific blogs which interests him/her.

The best thing what TechBlog provides is that each and every blog posted here is reviewed by various reviewers around the world. Even every user can be a reviewer, because every user has a score point and after a specific points you will be promoted to "Reviewer".

In TechBlog, every user goes through various stages according to his activites and his keenness to the knowledge he's looking for. Every blog a user writes or every comment he posts takes raises his `rank` and increases his `level`. There are various levels in the system and each level gives a different access to the system. Following are some of the ranks and levels.


1. Level 1
	- Color: Iron
	- Rank: Attentive   
	- Points: 0 - 500
2. Level 2 
	- Color: Tin
	- Rank: Heedful
	- Points: 501 - 2000
3. Level 3 
	- Color: Copper 
	- Rank: Inquisitive 
	- Points: 2001 - 5000
4. Level 4
	- Color: Bronze 
	- Rank: Blogger     
	- Points: 5001 - 10000
5. Level 5 
	- Color: Silver 
	- Rank: Admirer     
	- Points: 10001 - 50000
6. Level 6 
	- Color: Gold   
	- Rank: Reviewer    
	- Points: 50001 - 500000

And if you cross this labyrinth there are more surprises ahead.
